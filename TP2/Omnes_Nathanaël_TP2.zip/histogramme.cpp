#include <iostream>
#include <fstream>
#include <fstream>
#include "Image2D.hpp"
#include "Color.hpp"
#include "Image2DWriter.hpp"
#include "Image2DReader.hpp"
#include "Accessor.hpp"
#include "Histogramme.hpp"

using namespace std;

int main( int argc, char** argv )
{
    typedef Image2D<unsigned char> GrayLevelImage2D;
    typedef Image2D<Color> ColorImage2D;
    typedef Image2DWriter<unsigned char> GrayLevelImage2DWriter;
    typedef ColorImage2D::Iterator Iterator;
    
    ColorImage2D img;

    ifstream input( argv[1] );
    try 
    {
        Image2DReader<Color>::read( img, input );
    }
    catch ( char const * msg ) 
    {
        std::cerr << "Exception: " << msg << std::endl;
    }
    catch (...) 
    {
        std::cerr << "Exception." << std::endl;
    }
    input.close();


    Histogramme hist;
    hist.init( img.begin< ColorValueAccessor >(), img.end< ColorValueAccessor >() ); 

    //Convert ColorImage2D to GrayLevelImage2D
    GrayLevelImage2D imgGrayScale( img.w(), img.h() );
    
    typedef ColorImage2D::GenericConstIterator< ColorValueAccessor > ColorValueConstIterator;

    // Notez comment on appelle la méthode \b générique `begin` de `Image2D`.
    ColorValueConstIterator itRed = img.begin< ColorValueAccessor >();

    // On écrit la composante verte dans l'image en niveaux de gris.
    for ( GrayLevelIterator it = imgGrayScale.begin(), itE = imgGrayScale.end(); it != itE; ++it )
    {
        *it = *itRed;
        ++itRed;
    }

    //-----------------------------------------------------------------------------
    
    std::ofstream output( argv[2] ); // récupère le 2eme argument.
    bool ok3 = GrayLevelImage2DWriter::write( imgRed, output, false );
    if ( !ok3 )
    {
        std::cerr << "Error writing output file." << std::endl;
        return 1;
    }
    output.close();

    return 0;
}